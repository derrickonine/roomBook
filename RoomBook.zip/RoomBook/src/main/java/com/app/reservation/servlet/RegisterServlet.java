package com.app.reservation.servlet;

import com.app.reservation.entity.Role;
import com.app.reservation.entity.Utilisateur;
import com.app.reservation.util.PasswordUtil;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.UserTransaction;

import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String prenom = req.getParameter("prenom");
        String nom = req.getParameter("nom");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String password2 = req.getParameter("password2");

        if (prenom == null || nom == null || email == null || password == null || password2 == null
                || prenom.isBlank() || nom.isBlank() || email.isBlank() || password.isBlank() || password2.isBlank()) {
            req.setAttribute("error", "Champs manquants");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        if (!password.equals(password2)) {
            req.setAttribute("error", "Les mots de passe ne correspondent pas");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        // Mini règles "entreprise" (simple, mais utile)
        String emailNorm = email.trim().toLowerCase();
        if (!emailNorm.contains("@") || emailNorm.length() < 6) {
            req.setAttribute("error", "Email invalide");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }
        if (password.length() < 6) {
            req.setAttribute("error", "Mot de passe trop court (min 6)");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        try {
            utx.begin();

            boolean exists = em.createQuery(
                            "SELECT COUNT(u) FROM Utilisateur u WHERE u.email = :e",
                            Long.class)
                    .setParameter("e", emailNorm)
                    .getSingleResult() > 0;

            if (exists) {
                utx.rollback();
                req.setAttribute("error", "Un compte existe déjà avec cet email");
                req.getRequestDispatcher("register.jsp").forward(req, resp);
                return;
            }

            Utilisateur u = new Utilisateur();
            u.setPrenom(prenom.trim());
            u.setNom(nom.trim());
            u.setEmail(emailNorm);
            u.setRole(Role.USER);
            u.setMotDePasse(PasswordUtil.hash(password));

            em.persist(u);
            utx.commit();

            // ✅ Protection session fixation (comme login)
            HttpSession old = req.getSession(false);
            if (old != null) old.invalidate();
            HttpSession session = req.getSession(true);
            session.setAttribute("user", u);

            resp.sendRedirect("index.jsp?msg=Compte%20cree%20avec%20succes");

        } catch (Exception e) {
            try { utx.rollback(); } catch (Exception ignore) {}
            req.setAttribute("error", "Erreur lors de la création du compte");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
        }
    }
}
