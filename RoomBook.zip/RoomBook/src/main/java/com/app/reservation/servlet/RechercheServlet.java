package com.app.reservation.servlet;

import com.app.reservation.entity.Reservation;
import com.app.reservation.entity.Salle;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@WebServlet("/recherche")
public class RechercheServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // paramètres (facultatifs)
        String salleIdStr = req.getParameter("salleId");
        String dateStr = req.getParameter("date");
        String debutStr = req.getParameter("debut");
        String finStr = req.getParameter("fin");

        Long salleId = null;
        LocalDate date = null;
        LocalTime debut = null;
        LocalTime fin = null;

        try { if (salleIdStr != null && !salleIdStr.isBlank()) salleId = Long.parseLong(salleIdStr); } catch (Exception ignore) {}
        try { if (dateStr != null && !dateStr.isBlank()) date = LocalDate.parse(dateStr); } catch (Exception ignore) {}
        try { if (debutStr != null && !debutStr.isBlank()) debut = LocalTime.parse(debutStr); } catch (Exception ignore) {}
        try { if (finStr != null && !finStr.isBlank()) fin = LocalTime.parse(finStr); } catch (Exception ignore) {}

        StringBuilder jpql = new StringBuilder(
                "SELECT DISTINCT r FROM Reservation r " +
                "LEFT JOIN FETCH r.salle " +
                "LEFT JOIN FETCH r.utilisateur " +
                "LEFT JOIN FETCH r.equipements " +
                "WHERE 1=1 ");

        if (salleId != null) jpql.append(" AND r.salle.id = :sid ");
        if (date != null) jpql.append(" AND r.dateReservation = :d ");
        if (debut != null && fin != null) jpql.append(" AND r.heureDebut < :fin AND r.heureFin > :debut ");

        jpql.append(" ORDER BY r.dateReservation DESC, r.heureDebut DESC ");

        var q = em.createQuery(jpql.toString(), Reservation.class);
        if (salleId != null) q.setParameter("sid", salleId);
        if (date != null) q.setParameter("d", date);
        if (debut != null && fin != null) {
            q.setParameter("debut", debut);
            q.setParameter("fin", fin);
        }

        List<Reservation> reservations = q.getResultList();

        // Liste salles pour le formulaire recherche
        List<Salle> salles = em.createQuery("SELECT s FROM Salle s ORDER BY s.nom", Salle.class).getResultList();

        req.setAttribute("reservations", reservations);
        req.setAttribute("salles", salles);

        req.getRequestDispatcher("listeReservations.jsp").forward(req, resp);
    }
}
