package com.app.reservation.servlet;

import com.app.reservation.entity.Reservation;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.UserTransaction;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@WebServlet("/modifier")
public class ModifierReservationServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String idStr = req.getParameter("id");
        if (idStr == null || idStr.isBlank()) {
            resp.sendRedirect("recherche");
            return;
        }

        Reservation r = em.find(Reservation.class, Long.parseLong(idStr));
        if (r == null) {
            resp.sendRedirect("recherche");
            return;
        }

        req.setAttribute("reservation", r);
        req.getRequestDispatcher("modifierReservation.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        try {
            Long id = Long.parseLong(req.getParameter("id"));
            LocalDate date = LocalDate.parse(req.getParameter("dateReservation"));
            LocalTime debut = LocalTime.parse(req.getParameter("heureDebut"));
            LocalTime fin = LocalTime.parse(req.getParameter("heureFin"));

            if (!fin.isAfter(debut)) {
                resp.sendRedirect("modifier?id=" + id + "&msg=Heure%20fin%20invalide");
                return;
            }

            utx.begin();

            Reservation r = em.find(Reservation.class, id);
            if (r == null) {
                utx.rollback();
                resp.sendRedirect("recherche");
                return;
            }

            // conflit salle (exclure la réservation courante)
            List<Reservation> overlaps = em.createQuery(
                            "SELECT rr FROM Reservation rr WHERE rr.id <> :id AND rr.salle.id = :sid AND rr.dateReservation = :d " +
                                    "AND rr.heureDebut < :fin AND rr.heureFin > :debut",
                            Reservation.class)
                    .setParameter("id", id)
                    .setParameter("sid", r.getSalle().getId())
                    .setParameter("d", date)
                    .setParameter("debut", debut)
                    .setParameter("fin", fin)
                    .getResultList();

            if (!overlaps.isEmpty()) {
                utx.rollback();
                resp.sendRedirect("modifier?id=" + id + "&msg=Conflit%20d%20horaire%20pour%20cette%20salle");
                return;
            }

            r.setDateReservation(date);
            r.setHeureDebut(debut);
            r.setHeureFin(fin);

            em.merge(r);
            utx.commit();

            resp.sendRedirect("recherche");
        } catch (Exception ex) {
            try { utx.rollback(); } catch (Exception ignore) {}
            resp.sendRedirect("erreur.jsp?msg=Erreur%20modification");
        }
    }
}
