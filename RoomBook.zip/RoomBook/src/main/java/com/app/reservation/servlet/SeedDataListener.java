package com.app.reservation.servlet;

import com.app.reservation.entity.Equipement;
import com.app.reservation.entity.Role;
import com.app.reservation.entity.Salle;
import com.app.reservation.entity.Utilisateur;
import com.app.reservation.util.PasswordUtil;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.transaction.UserTransaction;

/**
 * Seed de données (demo) : utilisateurs, salles, équipements.
 * Version robuste PostgreSQL :
 * - crée les comptes système s'ils n'existent pas (même si d'autres users existent)
 * - idem pour salles / équipements
 */
@WebListener
public class SeedDataListener implements ServletContextListener {

    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            utx.begin();

            // === Users système (ne dépend PLUS de userCount==0) ===
            ensureUser("admin@roombook.local",  "Agence",  "Admin",   "admin123",   Role.ADMIN);
            ensureUser("manager@roombook.local","Plateau", "Manager", "manager123", Role.MANAGER);
            ensureUser("user@roombook.local",   "Equipe",  "User",    "user123",    Role.USER);

            // === Salles ===
            if (count("SELECT COUNT(s) FROM Salle s") == 0) {
                Salle s1 = new Salle(); s1.setNom("Kigali");     s1.setCapacite(8);  em.persist(s1);
                Salle s2 = new Salle(); s2.setNom("Bujumbura");  s2.setCapacite(10); em.persist(s2);
                Salle s3 = new Salle(); s3.setNom("Libreville"); s3.setCapacite(12); em.persist(s3);
            }

            // === Equipements ===
            if (count("SELECT COUNT(e) FROM Equipement e") == 0) {
                Equipement e1 = new Equipement(); e1.setNom("Video-projecteur");   e1.setDescription("Projecteur HD");      em.persist(e1);
                Equipement e2 = new Equipement(); e2.setNom("Television");         e2.setDescription("Ecran 55 pouces");    em.persist(e2);
                Equipement e3 = new Equipement(); e3.setNom("Poste telephonique"); e3.setDescription("Conference audio");   em.persist(e3);
                Equipement e4 = new Equipement(); e4.setNom("Araignee conf-call"); e4.setDescription("Microphone omni");    em.persist(e4);
                Equipement e5 = new Equipement(); e5.setNom("Paper board");        e5.setDescription("Tableau + marqueurs"); em.persist(e5);
            }

            utx.commit();
        } catch (Exception ex) {
            ex.printStackTrace(); // IMPORTANT: pour voir l'erreur dans server.log
            try { utx.rollback(); } catch (Exception ignore) {}
        }
    }

    private long count(String jpqlCount) {
        return em.createQuery(jpqlCount, Long.class).getSingleResult();
    }

    private void ensureUser(String email, String prenom, String nom, String rawPassword, Role role) {
        boolean exists = em.createQuery("SELECT COUNT(u) FROM Utilisateur u WHERE u.email = :e", Long.class)
                .setParameter("e", email)
                .getSingleResult() > 0;

        if (exists) return;

        Utilisateur u = new Utilisateur();
        u.setEmail(email);
        u.setPrenom(prenom);
        u.setNom(nom);
        u.setRole(role);
        u.setMotDePasse(PasswordUtil.hash(rawPassword)); // BCrypt (12)
        em.persist(u);
    }
}
