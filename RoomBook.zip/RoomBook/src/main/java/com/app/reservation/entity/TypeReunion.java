package com.app.reservation.entity;

public enum TypeReunion {
    INTERNE,
    AUDIO_CONFERENCE,
    VIDEO_CONFERENCE
}
