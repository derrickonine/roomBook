package com.app.reservation.entity;

public enum Role {
    USER,
    MANAGER,
    ADMIN
}
