package com.app.reservation.servlet;

import com.app.reservation.entity.Equipement;
import com.app.reservation.entity.Reservation;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class PdfService {

    public static void writeCalendrierPdf(OutputStream out, List<Reservation> reservations,
                                          LocalDate start, LocalDate end, String view) throws IOException {

        try (PDDocument doc = new PDDocument()) {

            float margin = 50;
            float lineGap = 16;

            PDPage page = new PDPage(PDRectangle.A4);
            doc.addPage(page);

            PDPageContentStream cs = new PDPageContentStream(doc, page);

            float y = page.getMediaBox().getHeight() - margin;

            // Titre
            cs.beginText();
            cs.setFont(PDType1Font.HELVETICA_BOLD, 16);
            cs.newLineAtOffset(margin, y);
            cs.showText("Calendrier des reservations (" + view + ") : " + start + " -> " + end.minusDays(1));
            cs.endText();

            y -= 30;

            for (Reservation r : reservations) {
                if (y < margin + 60) {
                    cs.close();
                    page = new PDPage(PDRectangle.A4);
                    doc.addPage(page);
                    cs = new PDPageContentStream(doc, page);
                    y = page.getMediaBox().getHeight() - margin;
                }

                String header = r.getDateReservation() + " " + r.getHeureDebut() + "-" + r.getHeureFin()
                        + " | " + (r.getSalle() != null ? r.getSalle().getNom() : "-")
                        + " | " + r.getTitre();

                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA_BOLD, 11);
                cs.newLineAtOffset(margin, y);
                cs.showText(truncate(header, 110));
                cs.endText();

                y -= 13;

                String eq = r.getEquipements() == null ? "" :
                        r.getEquipements().stream().map(Equipement::getNom).sorted().collect(Collectors.joining(", "));
                String details = "Type: " + r.getTypeReunion()
                        + " | Organisateur: " + (r.getUtilisateur() != null ? r.getUtilisateur().getEmail() : "-")
                        + (eq.isBlank() ? "" : " | Equipements: " + eq);

                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA, 10);
                cs.newLineAtOffset(margin, y);
                cs.showText(truncate(details, 120));
                cs.endText();

                y -= lineGap;
            }

            cs.close();
            doc.save(out);
        }
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(0, max - 3)) + "...";
    }
}
