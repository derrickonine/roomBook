package com.app.reservation.servlet;

import com.app.reservation.entity.Reservation;

import java.util.Arrays;

/**
 * Service mail "demo": on log dans la console WildFly.
 * (Pour un vrai envoi: Jakarta Mail + config SMTP côté serveur.)
 */
public class EmailService {

    public static void logInvitations(Reservation r) {
        String participants = r.getParticipants();
        if (participants == null || participants.isBlank()) return;

        String normalized = participants.replace("\n", ",").replace(";", ",");
        String[] emails = Arrays.stream(normalized.split(","))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .toArray(String[]::new);

        if (emails.length == 0) return;

        System.out.println("[RoomBook] Invitation (demo) :");
        System.out.println("  Titre: " + r.getTitre());
        System.out.println("  Salle: " + (r.getSalle() != null ? r.getSalle().getNom() : "-"));
        System.out.println("  Date: " + r.getDateReservation() + " " + r.getHeureDebut() + "-" + r.getHeureFin());
        System.out.println("  Participants: " + String.join(", ", emails));
    }
}
