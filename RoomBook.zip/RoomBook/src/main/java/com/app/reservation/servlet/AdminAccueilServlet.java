package com.app.reservation.servlet;

import com.app.reservation.entity.Utilisateur;
import com.app.reservation.entity.Role;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin")
public class AdminAccueilServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Protection simple côté servlet (en plus d’un Filter si tu en mets un)
        Utilisateur u = (Utilisateur) req.getSession().getAttribute("user");
        if (u == null) {
            resp.sendRedirect("login?err=Veuillez%20vous%20connecter");
            return;
        }
        if (u.getRole() != Role.ADMIN) {
            resp.sendRedirect("reservation?msg=Acces%20refuse");
            return;
        }

        List<Utilisateur> users = em.createQuery(
                        "SELECT u FROM Utilisateur u ORDER BY u.role DESC, u.email ASC",
                        Utilisateur.class
                )
                .getResultList();

        req.setAttribute("users", users);
        req.getRequestDispatcher("admin.jsp").forward(req, resp);
    }
}
