package com.app.reservation.servlet;

import com.app.reservation.entity.Reservation;
import com.app.reservation.entity.Utilisateur;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/mes-reservations")
public class MesReservationsServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Utilisateur sessionUser = (Utilisateur) req.getSession().getAttribute("user");
        if (sessionUser == null) {
            resp.sendRedirect("login?err=Veuillez%20vous%20connecter");
            return;
        }

        // Recharger l'utilisateur attaché (plus stable)
        Utilisateur u = em.find(Utilisateur.class, sessionUser.getId());
        if (u == null) {
            req.getSession().invalidate();
            resp.sendRedirect("login?err=Session%20invalide");
            return;
        }

        List<Reservation> reservations = em.createQuery(
                        "SELECT DISTINCT r FROM Reservation r " +
                                "LEFT JOIN FETCH r.salle " +
                                "LEFT JOIN FETCH r.equipements " +
                                "WHERE r.utilisateur.id = :uid " +
                                "ORDER BY r.dateReservation DESC, r.heureDebut DESC",
                        Reservation.class)
                .setParameter("uid", u.getId())
                .getResultList();

        req.setAttribute("reservations", reservations);
        req.getRequestDispatcher("mesReservations.jsp").forward(req, resp);
    }
}
