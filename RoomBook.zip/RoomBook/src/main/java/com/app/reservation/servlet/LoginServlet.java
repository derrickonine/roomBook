package com.app.reservation.servlet;

import com.app.reservation.entity.Utilisateur;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String email = req.getParameter("username");
        String password = req.getParameter("password");

        if (email == null || password == null || email.isBlank() || password.isBlank()) {
            req.setAttribute("error", "Champs manquants");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
            return;
        }

        Utilisateur user = em.createQuery(
                        "SELECT u FROM Utilisateur u WHERE u.email = :email",
                        Utilisateur.class)
                .setParameter("email", email.trim().toLowerCase())
                .getResultStream()
                .findFirst()
                .orElse(null);

        boolean ok = (user != null)
                && com.app.reservation.util.PasswordUtil.verify(password, user.getMotDePasse());

        if (ok) {
            // ✅ Protection contre session fixation
            HttpSession old = req.getSession(false);
            if (old != null) old.invalidate();
            HttpSession session = req.getSession(true);
            session.setAttribute("user", user);

            // ✅ Redirection vers page demandée (si présente)
            String redirect = req.getParameter("redirect");
            if (redirect != null && !redirect.isBlank() && redirect.startsWith("/")) {
                resp.sendRedirect(req.getContextPath() + redirect);
            } else {
                resp.sendRedirect("index.jsp");
            }
            return;
        }

        req.setAttribute("error", "Identifiants invalides");
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }
}
