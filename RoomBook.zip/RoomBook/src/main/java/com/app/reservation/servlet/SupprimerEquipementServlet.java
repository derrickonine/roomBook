package com.app.reservation.servlet;

import com.app.reservation.entity.Equipement;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/supprimerEquipement")
public class SupprimerEquipementServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr == null || idStr.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/equipements?msg=ID%20invalide");
            return;
        }

        try {
            Long id = Long.parseLong(idStr);
            Equipement e = em.find(Equipement.class, id);
            if (e != null) {
                em.remove(e);
                resp.sendRedirect(req.getContextPath() + "/equipements?msg=Equipement%20supprime");
            } else {
                resp.sendRedirect(req.getContextPath() + "/equipements?msg=Equipement%20introuvable");
            }
        } catch (Exception ex) {
            resp.sendRedirect(req.getContextPath() + "/equipements?msg=Suppression%20impossible");
        }
    }
}
