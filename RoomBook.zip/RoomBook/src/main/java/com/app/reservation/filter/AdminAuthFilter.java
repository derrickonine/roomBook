package com.app.reservation.filter;

import com.app.reservation.entity.Role;
import com.app.reservation.entity.Utilisateur; // ✅ IMPORT MANQUANT
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Protection simple (session) des pages back-office.
 * ADMIN: accès total
 * MANAGER: accès impression + listes (sans CRUD)
 */
@WebFilter(urlPatterns = {
        "/admin",
        "/salles",
        "/equipements",
        "/impression",
        "/ajouterSalle",
        "/ajouterEquipement",
        "/supprimer",
        "/supprimerEquipement",
        "/supprimerSalle",
        "/adminRole"
})
public class AdminAuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        Utilisateur user = (Utilisateur) req.getSession().getAttribute("user");
        Role role = (user != null) ? user.getRole() : null;

        // Pas connecté
        if (role == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String path = req.getServletPath();

        // Routes sensibles => ADMIN uniquement
        boolean adminOnly = path.startsWith("/ajouter") || path.startsWith("/supprimer");

        if (adminOnly && role != Role.ADMIN) {
            resp.sendRedirect(req.getContextPath()
                    + "/erreur.jsp?msg=Acces%20refuse%20(Admin%20requis)");
            return;
        }

        // Page admin visible seulement ADMIN ou MANAGER
        if (path.equals("/admin") && (role != Role.ADMIN && role != Role.MANAGER)) {
            resp.sendRedirect(req.getContextPath()
                    + "/erreur.jsp?msg=Acces%20refuse");
            return;
        }

        chain.doFilter(request, response);
    }
}
