package com.app.reservation.servlet;

import com.app.reservation.entity.Reservation;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/supprimer")
public class SupprimerReservationServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr == null || idStr.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/recherche");
            return;
        }

        try {
            Long id = Long.parseLong(idStr);
            Reservation r = em.find(Reservation.class, id);
            if (r != null) {
                em.remove(r);
            }
            resp.sendRedirect(req.getContextPath() + "/recherche");
        } catch (Exception ex) {
            resp.sendRedirect(req.getContextPath() + "/recherche");
        }
    }
}
