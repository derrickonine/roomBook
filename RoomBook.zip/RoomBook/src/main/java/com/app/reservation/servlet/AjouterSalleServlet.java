package com.app.reservation.servlet;

import com.app.reservation.entity.Salle;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.UserTransaction;

import java.io.IOException;

@WebServlet("/ajouterSalle")
public class AjouterSalleServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String nom = req.getParameter("nom");
        String capaciteStr = req.getParameter("capacite");

        if (nom == null || nom.trim().isEmpty() || capaciteStr == null || capaciteStr.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/salles?msg=Champs%20obligatoires");
            return;
        }

        int capacite;
        try {
            capacite = Integer.parseInt(capaciteStr.trim());
            if (capacite <= 0) {
                resp.sendRedirect(req.getContextPath() + "/salles?msg=Capacite%20invalide");
                return;
            }
        } catch (NumberFormatException e) {
            resp.sendRedirect(req.getContextPath() + "/salles?msg=Capacite%20invalide");
            return;
        }

        try {
            utx.begin();

            Salle s = new Salle();
            s.setNom(nom.trim());
            s.setCapacite(capacite);

            em.persist(s);

            utx.commit();
            resp.sendRedirect(req.getContextPath() + "/salles?msg=Salle%20ajoutee");
        } catch (Exception ex) {
            try { utx.rollback(); } catch (Exception ignore) {}
            resp.sendRedirect(req.getContextPath() + "/salles?msg=Erreur%20lors%20de%20l%27ajout");
        }
    }
}
