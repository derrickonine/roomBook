package com.app.reservation.servlet;

import com.app.reservation.entity.Salle;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.UserTransaction;

import java.io.IOException;

@WebServlet("/supprimerSalle")
public class SupprimerSalleServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String idStr = req.getParameter("id");
        if (idStr == null || idStr.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/salles?msg=ID%20invalide");
            return;
        }

        Long id;
        try {
            id = Long.parseLong(idStr.trim());
        } catch (NumberFormatException e) {
            resp.sendRedirect(req.getContextPath() + "/salles?msg=ID%20invalide");
            return;
        }

        try {
            utx.begin();

            Salle s = em.find(Salle.class, id);
            if (s == null) {
                utx.commit();
                resp.sendRedirect(req.getContextPath() + "/salles?msg=Salle%20introuvable");
                return;
            }

            em.remove(s);

            utx.commit();
            resp.sendRedirect(req.getContextPath() + "/salles?msg=Salle%20supprimee");
        } catch (Exception ex) {
            try { utx.rollback(); } catch (Exception ignore) {}
            resp.sendRedirect(req.getContextPath() + "/salles?msg=Suppression%20impossible");
        }
    }
}
