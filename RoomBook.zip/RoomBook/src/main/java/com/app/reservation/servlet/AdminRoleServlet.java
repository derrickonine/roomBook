package com.app.reservation.servlet;

import com.app.reservation.entity.Role;
import com.app.reservation.entity.Utilisateur;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.UserTransaction;

import java.io.IOException;

@WebServlet("/adminRole")
public class AdminRoleServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Protection : seulement ADMIN
        Utilisateur sessionUser = (Utilisateur) req.getSession().getAttribute("user");
        if (sessionUser == null) {
            resp.sendRedirect("login?err=Veuillez%20vous%20connecter");
            return;
        }
        if (sessionUser.getRole() != Role.ADMIN) {
            resp.sendRedirect("reservation?msg=Acces%20refuse");
            return;
        }

        String idStr = req.getParameter("userId");
        String roleStr = req.getParameter("role");

        if (idStr == null || roleStr == null || idStr.isBlank() || roleStr.isBlank()) {
            resp.sendRedirect("admin?msg=Parametres%20invalides");
            return;
        }

        try {
            Long id = Long.parseLong(idStr.trim());
            Role role = Role.valueOf(roleStr.trim());

            utx.begin();
            Utilisateur u = em.find(Utilisateur.class, id);
            if (u != null) {
                u.setRole(role);
                // u est déjà managé après find(), merge() pas obligatoire
            }
            utx.commit();

            resp.sendRedirect("admin?msg=Role%20mis%20a%20jour");
        } catch (Exception ex) {
            try { utx.rollback(); } catch (Exception ignore) {}
            resp.sendRedirect("erreur.jsp?msg=Erreur%20changement%20role");
        }
    }
}
