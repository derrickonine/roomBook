package com.app.reservation.servlet;

import com.app.reservation.entity.Equipement;
import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/equipements")
public class ListeEquipementsServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Equipement> equipements = em.createQuery("SELECT e FROM Equipement e ORDER BY e.nom", Equipement.class)
                .getResultList();

        req.setAttribute("equipements", equipements);
        req.getRequestDispatcher("equipements.jsp").forward(req, resp);
    }
}
