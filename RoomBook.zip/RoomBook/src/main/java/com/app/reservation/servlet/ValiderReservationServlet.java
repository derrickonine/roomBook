package com.app.reservation.servlet;

import com.app.reservation.entity.*;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.UserTransaction;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@WebServlet("/reserver")
public class ValiderReservationServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Resource
    private UserTransaction utx;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // ===== 1. Lecture des paramètres =====
        String titre = req.getParameter("titre");
        String description = req.getParameter("description");
        String participants = req.getParameter("participants");
        String typeStr = req.getParameter("typeReunion");

        String dateStr = req.getParameter("dateReservation");
        String heureDebutStr = req.getParameter("heureDebut");
        String heureFinStr = req.getParameter("heureFin");
        String salleIdStr = req.getParameter("salleId");

        String[] equipementIds = req.getParameterValues("equipementIds");

        // ===== 2. Validation basique =====
        if (titre == null || titre.isBlank()
                || dateStr == null || heureDebutStr == null || heureFinStr == null || salleIdStr == null
                || dateStr.isBlank() || heureDebutStr.isBlank() || heureFinStr.isBlank() || salleIdStr.isBlank()) {
            resp.sendRedirect("reservation?msg=Champs%20manquants");
            return;
        }

        LocalDate date;
        LocalTime heureDebut;
        LocalTime heureFin;
        long salleId;

        try {
            date = LocalDate.parse(dateStr.trim());
            heureDebut = LocalTime.parse(heureDebutStr.trim());
            heureFin = LocalTime.parse(heureFinStr.trim());
            salleId = Long.parseLong(salleIdStr.trim());
        } catch (Exception e) {
            resp.sendRedirect("reservation?msg=Parametres%20invalides");
            return;
        }

        if (!heureFin.isAfter(heureDebut)) {
            resp.sendRedirect("reservation?msg=Heure%20de%20fin%20doit%20etre%20apres%20heure%20de%20debut");
            return;
        }

        TypeReunion typeReunion = TypeReunion.INTERNE;
        try {
            if (typeStr != null && !typeStr.isBlank()) {
                typeReunion = TypeReunion.valueOf(typeStr.trim());
            }
        } catch (Exception ignored) {}

        try {
            utx.begin();

            // ===== 3. Salle =====
            Salle salle = em.find(Salle.class, salleId);
            if (salle == null) {
                utx.rollback();
                resp.sendRedirect("reservation?msg=Salle%20introuvable");
                return;
            }

            // ===== 4. Conflit salle =====
            List<Reservation> overlapsSalle = em.createQuery(
                            "SELECT r FROM Reservation r " +
                                    "WHERE r.salle.id = :sid AND r.dateReservation = :d " +
                                    "AND r.heureDebut < :fin AND r.heureFin > :debut",
                            Reservation.class)
                    .setParameter("sid", salleId)
                    .setParameter("d", date)
                    .setParameter("debut", heureDebut)
                    .setParameter("fin", heureFin)
                    .getResultList();

            if (!overlapsSalle.isEmpty()) {
                utx.rollback();
                resp.sendRedirect("reservation?msg=Cette%20salle%20est%20deja%20reservee");
                return;
            }

            // ===== 5. Utilisateur =====
            Utilisateur user = (Utilisateur) req.getSession().getAttribute("user");
            if (user == null) {
                // Mode invité : on prend les infos saisies (ou des defaults)
                String prenomInv = req.getParameter("utilisateurPrenom");
                String nomInv = req.getParameter("utilisateurNom");
                String emailInv = req.getParameter("utilisateurEmail");

                if (prenomInv == null || prenomInv.isBlank()) prenomInv = "Invité";
                if (nomInv == null || nomInv.isBlank()) nomInv = "Roombook";
                if (emailInv == null || emailInv.isBlank()) {
                    emailInv = "invite+" + System.currentTimeMillis() + "@local";
                }

                Utilisateur invite = new Utilisateur();
                invite.setPrenom(prenomInv.trim());
                invite.setNom(nomInv.trim());
                invite.setEmail(emailInv.trim().toLowerCase());
                invite.setMotDePasse("-");
                invite.setRole(Role.USER);
                em.persist(invite);
                user = invite;
            } else {
                // recharge attaché
                user = em.find(Utilisateur.class, user.getId());
            }

            // ===== 6. Équipements =====
            Set<Equipement> selectedEquipements = new HashSet<>();
            if (equipementIds != null) {
                for (String idStr : equipementIds) {
                    try {
                        Long eid = Long.parseLong(idStr);
                        Equipement e = em.find(Equipement.class, eid);
                        if (e != null) selectedEquipements.add(e);
                    } catch (Exception ignored) {}
                }
            }

            // ===== 7. Conflit équipements =====
            if (!selectedEquipements.isEmpty()) {

                List<Long> eids = selectedEquipements.stream()
                        .map(Equipement::getId)
                        .collect(Collectors.toList());

                List<Reservation> overlapsEq = em.createQuery(
                                "SELECT DISTINCT r FROM Reservation r JOIN r.equipements e " +
                                        "WHERE r.dateReservation = :d " +
                                        "AND r.heureDebut < :fin AND r.heureFin > :debut " +
                                        "AND e.id IN :eids",
                                Reservation.class)
                        .setParameter("d", date)
                        .setParameter("debut", heureDebut)
                        .setParameter("fin", heureFin)
                        .setParameter("eids", eids)
                        .getResultList();

                if (!overlapsEq.isEmpty()) {
                    utx.rollback();
                    resp.sendRedirect("reservation?msg=Equipement%20deja%20reserve");
                    return;
                }
            }

            // ===== 8. Création réservation =====
            Reservation r = new Reservation();
            r.setTitre(titre.trim());
            r.setDescription(description);
            r.setParticipants(participants);
            r.setTypeReunion(typeReunion);
            r.setDateReservation(date);
            r.setHeureDebut(heureDebut);
            r.setHeureFin(heureFin);
            r.setSalle(salle);
            r.setUtilisateur(user);
            r.setEquipements(selectedEquipements);

            em.persist(r);
            utx.commit();

            EmailService.logInvitations(r);
            resp.sendRedirect("confirmation.jsp");

        } catch (Exception e) {
            try { utx.rollback(); } catch (Exception ignored) {}
            e.printStackTrace(); // TEMPORAIRE: voir l'erreur exacte dans server.log
            resp.sendRedirect("erreur.jsp?msg=" + java.net.URLEncoder.encode(String.valueOf(e.getMessage()), "UTF-8"));

        }
    }
}
