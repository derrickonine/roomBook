package com.app.reservation.servlet;

import com.app.reservation.entity.Equipement;
import com.app.reservation.entity.Salle;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * Charge les salles/équipements et affiche le formulaire de réservation.
 */
@WebServlet("/reservation")
public class ReservationFormServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Salle> salles = em.createQuery("SELECT s FROM Salle s ORDER BY s.nom", Salle.class)
                .getResultList();
        List<Equipement> equipements = em.createQuery("SELECT e FROM Equipement e ORDER BY e.nom", Equipement.class)
                .getResultList();

        req.setAttribute("salles", salles);
        req.setAttribute("equipements", equipements);
        req.getRequestDispatcher("reservation.jsp").forward(req, resp);
    }
}
