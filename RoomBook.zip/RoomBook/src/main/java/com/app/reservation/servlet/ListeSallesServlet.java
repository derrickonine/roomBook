package com.app.reservation.servlet;

import com.app.reservation.entity.Salle;
import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/salles")
public class ListeSallesServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Salle> salles = em.createQuery("SELECT s FROM Salle s ORDER BY s.nom", Salle.class)
                .getResultList();

        req.setAttribute("salles", salles);
        req.getRequestDispatcher("salles.jsp").forward(req, resp);
    }
}
