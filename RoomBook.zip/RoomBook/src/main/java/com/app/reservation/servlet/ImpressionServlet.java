package com.app.reservation.servlet;

import com.app.reservation.entity.Reservation;
import com.app.reservation.entity.Salle;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

@WebServlet("/impression")
public class ImpressionServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String format = req.getParameter("format"); // html | pdf
        String view = req.getParameter("view");     // week | month
        String salleIdStr = req.getParameter("salleId");
        String startStr = req.getParameter("start"); // date de référence

        Long salleId = null;
        try { if (salleIdStr != null && !salleIdStr.isBlank()) salleId = Long.parseLong(salleIdStr); } catch (Exception ignore) {}

        LocalDate ref = LocalDate.now();
        try { if (startStr != null && !startStr.isBlank()) ref = LocalDate.parse(startStr); } catch (Exception ignore) {}

        LocalDate start = ref;
        LocalDate end = ref.plusDays(1);

        if ("month".equalsIgnoreCase(view)) {
            start = ref.withDayOfMonth(1);
            end = start.plusMonths(1);
        } else {
            // default week
            start = ref.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
            end = start.plusDays(7);
            view = "week";
        }

        StringBuilder jpql = new StringBuilder(
                "SELECT DISTINCT r FROM Reservation r " +
                "LEFT JOIN FETCH r.salle " +
                "LEFT JOIN FETCH r.utilisateur " +
                "LEFT JOIN FETCH r.equipements " +
                "WHERE r.dateReservation >= :start AND r.dateReservation < :end ");

        if (salleId != null) jpql.append(" AND r.salle.id = :sid ");
        jpql.append(" ORDER BY r.dateReservation ASC, r.heureDebut ASC ");

        var q = em.createQuery(jpql.toString(), Reservation.class)
                .setParameter("start", start)
                .setParameter("end", end);

        if (salleId != null) q.setParameter("sid", salleId);

        List<Reservation> reservations = q.getResultList();
        List<Salle> salles = em.createQuery("SELECT s FROM Salle s ORDER BY s.nom", Salle.class).getResultList();

        if ("pdf".equalsIgnoreCase(format)) {
            resp.setContentType("application/pdf");
            resp.setHeader("Content-Disposition", "attachment; filename=calendrier-" + view + ".pdf");
            PdfService.writeCalendrierPdf(resp.getOutputStream(), reservations, start, end, view);
            return;
        }

        req.setAttribute("reservations", reservations);
        req.setAttribute("salles", salles);
        req.setAttribute("view", view);
        req.setAttribute("start", start);
        req.setAttribute("end", end);

        req.getRequestDispatcher("impression.jsp").forward(req, resp);
    }
}
