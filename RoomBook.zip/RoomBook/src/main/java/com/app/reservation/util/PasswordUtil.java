package com.app.reservation.util;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Utilitaire mot de passe (demo pro).
 * - Stockage: BCrypt (hash + salt)
 * - Vérification: BCrypt.checkpw()
 */
public final class PasswordUtil {
    private PasswordUtil() {}

    public static String hash(String rawPassword) {
        if (rawPassword == null) throw new IllegalArgumentException("password null");
        return BCrypt.hashpw(rawPassword, BCrypt.gensalt(12));
    }

    public static boolean verify(String rawPassword, String hashed) {
        if (rawPassword == null || hashed == null) return false;
        try {
            return BCrypt.checkpw(rawPassword, hashed);
        } catch (Exception e) {
            return false;
        }
    }
}
