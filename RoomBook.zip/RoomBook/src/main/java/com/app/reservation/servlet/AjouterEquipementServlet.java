package com.app.reservation.servlet;

import com.app.reservation.entity.Equipement;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/ajouterEquipement")
public class AjouterEquipementServlet extends HttpServlet {

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String nom = req.getParameter("nom");
        String description = req.getParameter("description");

        if (nom == null || nom.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/equipements?msg=Nom%20obligatoire");
            return;
        }

        try {
            Equipement e = new Equipement();
            e.setNom(nom.trim());
            e.setDescription(description != null ? description.trim() : "");
            em.persist(e);
            resp.sendRedirect(req.getContextPath() + "/equipements?msg=Equipement%20ajoute");
        } catch (Exception ex) {
            resp.sendRedirect(req.getContextPath() + "/equipements?msg=Erreur%20lors%20de%20l%27ajout");
        }
    }
}
