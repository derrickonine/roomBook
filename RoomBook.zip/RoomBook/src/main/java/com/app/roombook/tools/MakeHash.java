package com.app.roombook.tools;

public class MakeHash {
    public static void main(String[] args) {
        String raw = "admin123";
        String hash = org.mindrot.jbcrypt.BCrypt
                .hashpw(raw, org.mindrot.jbcrypt.BCrypt.gensalt(10));
        System.out.println(hash);
    }
}
