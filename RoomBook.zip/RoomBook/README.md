# RoomBook (base: Roombook) — Jakarta EE 10 / WildFly / IntelliJ

Application web (Servlet + JSP + JPA) pour la **réservation de salles & équipements**, avec :
- Front Office : réservation, recherche (par salle/date/plage horaire), invitations (demo log)
- Impression : **semaine/mois** + **PDF** (PDFBox)
- Back Office (ADMIN) : CRUD salles/équipements + gestion des rôles (USER/MANAGER/ADMIN)

## Comptes seed (créés au démarrage)
- ADMIN : admin@roombook.local / admin123
- MANAGER : manager@roombook.local / manager123
- USER : user@roombook.local / user123

> Note: mots de passe en clair (démo). En prod : hash (bcrypt/argon2) + policies.

## Lancer dans IntelliJ + WildFly (recommandé)
1. Ouvrir le projet dans IntelliJ (comme projet Maven).
2. Configurer un serveur **WildFly** dans IntelliJ (Run/Debug Configurations).
3. Déployer l'artefact **WAR** généré par IntelliJ (ou via Maven wrapper si tu veux).

## Base de données
- `persistence.xml` utilise `java:jboss/datasources/ExampleDS` (H2 embarquée WildFly)
- Schéma en `create` : la DB est recréée à chaque redeploy.

## URL utiles
- Accueil : `/index.jsp`
- Nouvelle réservation : `/reservation`
- Recherche : `/recherche`
- Impression : `/impression`
- Login : `/login`
- Back office : `/admin`

## Impression PDF
Dans `/impression`, clique **Télécharger PDF** (génération serveur via PDFBox).


## Comptes de démonstration (seed)

Ces identifiants sont **documentés ici** (et ne sont pas affichés dans l’UI).

- ADMIN : `admin@roombook.local` / `admin123`
- MANAGER : `manager@roombook.local` / `manager123`
- USER : `user@roombook.local` / `user123`

> Note : pour une application production, on utiliserait un fournisseur d’identité (SSO) et une politique mot de passe. Ici, les mots de passe sont stockés en **hash BCrypt** côté DB.

